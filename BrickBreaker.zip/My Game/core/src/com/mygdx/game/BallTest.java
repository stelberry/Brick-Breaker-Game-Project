package com.mygdx.game;

import com.badlogic.gdx.Gdx;

import static org.junit.jupiter.api.Assertions.*;

class BallTest {

    @org.junit.jupiter.api.Test
    void update() {

      Ball b = new Ball(46,53);
      b.ballX = 20;
      b.dx = 2;
      assertEquals(b.ballX, 20);
      b.update(640,480, 40, 40, 40, 40);
      assertEquals(b.ballX, 24);
      assertEquals(b.dx, 2);

    }

}

