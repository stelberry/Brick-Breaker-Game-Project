package com.mygdx.game;

public class Bar {
    int barX = 200;
    int barY = 20;
    int bar_width, bar_height;

    public Bar( int bar_width, int bar_height) {
        this.bar_width = bar_width;
        this.bar_height = bar_height;
    }

    public void move (int window_width){
        if (barX < 0) barX = 0;
        if (barX > (window_width - bar_width)) barX = window_width - bar_width;

    }
}

