package com.mygdx.game;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class BarTest {
    private Bar bar;
    @BeforeEach
    void setUp() {
        bar = new Bar(30, 30);
    }
@Test
    void testMoveBeyondRightEdge() {
        bar.barX = 850; // Beyond right edge by 50 units
        bar.move(800);
        assertEquals(770, bar.barX); // Should reset to (window_width - bar_width) when exceeding right edge
    }
@Test
    void testMoveWithinWindow() {
        bar.barX = 200;
        bar.move(800);
        assertEquals(200, bar.barX); // Should remain the same within window bounds
    }
    @Test
    void testMoveToLeftEdge() {
        bar.barX = -50;
        bar.move(800);
        assertEquals(0, bar.barX); // Should reset to 0 when exceeding left edge
    }
}
