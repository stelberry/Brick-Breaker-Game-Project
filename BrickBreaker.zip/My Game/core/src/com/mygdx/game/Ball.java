package com.mygdx.game;

public class Ball {
    int ballX = 35;
    int ballY = 35;
    int ball_width, ball_height;
    int dx = 1;
    int dy = 1;

    public Ball( int ball_width, int ball_height) {
        this.ball_width = ball_width;
        this.ball_height = ball_height;
    }


    public boolean update(int window_width, int window_height, int barX, int barY, int bar_width, int bar_height) {
        ballX += dx * 2;
        ballY += dy * 2;
        if (ballX < 0 || ballX > (window_width - ball_width)){
            dx *= -1;
            return true;
        }
        if (ballY > (window_height - ball_height)){
            dy *= -1;
            return true;
        }

        if (ballX < barX + bar_width && ballX + ball_width > barX
                && ballY < barY + bar_height -20 && ballY + ball_height > barY) {
            dy *= -1;
            return true;
        }
        return false;
    }



}
