package com.mygdx.game;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.utils.ScreenUtils;


import java.awt.*;
import java.util.*;

public class MyGdxGame extends ApplicationAdapter {
	SpriteBatch batch;
	Sound bounce_sound;

	Ball ball;
	Bar bar;
	Texture img;
	Texture img2;
	Texture img3;

	int barX = 200;
	int barY = 20;

	int bar_height = 0;
	int bar_width = 0;
	int ball_width = 0;
	int ball_height = 0;
	int window_width = 0;
	int window_height = 0;
	public int map[][];
	public int brickWidth = 0;
	public int brickHeight = 0;
	int row = 4;
	int col = 7;


		@Override
	public void create() {
			batch = new SpriteBatch();
			img = new Texture("ball2 2 (1).png");
			img2 = new Texture("bar1.png");
			img3 = new Texture("brick.png");
			bar_width = img2.getWidth();
			bar_height = img2.getHeight();
			ball_width = img.getWidth();
			ball_height = img.getHeight();
			brickHeight = img3.getHeight();
			brickWidth = img3.getWidth();
			bounce_sound = Gdx.audio.newSound(Gdx.files.internal("baby squeak toy.mp3"));
			ball = new Ball(ball_width, ball_height);
			bar = new Bar(bar_width, bar_height);
			window_height = Gdx.graphics.getHeight();
			window_width = Gdx.graphics.getWidth();
				map = new int[row][col];
				for(int i = 0; i < map.length; i++){
					for(int j=0; j<map[0].length;j++){
						map[i][j] = 1;
					}
				}
				brickWidth = 540/col;
				brickHeight = 150/row;


		}

	@Override
	public void render() {
		ScreenUtils.clear(0, 0, 0, 0);
		batch.begin();
		if (ball.update(window_width, window_height, bar.barX, bar.barY, bar_width, bar_height) == true) {
			bounce_sound.play();
		}
		batch.draw(img2, bar.barX, bar.barY);
		batch.draw(img, ball.ballX, ball.ballY);
		for (int i = 0; i < map.length; i++) {
			for (int j = 0; j < map[0].length; j++) {
				if (map[i][j] > 0) {
					int brickX = j * brickWidth + 50;
					int brickY = i * brickHeight + 320;
					if (ball.ballX < brickX + brickWidth &&
							ball.ballX + ball_width > brickX &&
							ball.ballY < brickY + brickHeight &&
							ball.ballY + ball_height > brickY) {
						map[i][j] = 0;
						bounce_sound.play();
						float collisionX = (ball.ballX + ball_width / 2) - (brickX + brickWidth / 2);
						float collisionY = (ball.ballY + ball_height / 2) - (brickY + brickHeight / 2);
						if (Math.abs(collisionX) > Math.abs(collisionY)) {
							ball.dx *= -1;
						} else {
							ball.dy *= -1;
						}
					} else {
						batch.draw(img3, brickX, brickY, brickWidth, brickHeight);
					}
				}
			}
		}

		if (Gdx.input.isKeyPressed(Input.Keys.LEFT)) bar.barX -= 200 * Gdx.graphics.getDeltaTime();
		if (Gdx.input.isKeyPressed(Input.Keys.RIGHT)) bar.barX += 200 * Gdx.graphics.getDeltaTime();

		bar.move(window_width);

		batch.end();


	}
	@Override
	public void dispose() {
		batch.dispose();
		img.dispose();
		img2.dispose();
		img3.dispose();
	}

}

